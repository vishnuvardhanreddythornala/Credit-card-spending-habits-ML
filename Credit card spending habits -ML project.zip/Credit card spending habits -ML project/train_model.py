# train_model.py

import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier

# Load and clean data
df = pd.read_csv("Credit card transactions - India - Simple.csv", index_col='index')
df.dropna(inplace=True)

# =========================
# Model 1: Expense Category Predictor
# =========================

le_city = LabelEncoder()
le_card = LabelEncoder()
le_gender = LabelEncoder()
le_exp = LabelEncoder()

df["City_encoded"] = le_city.fit_transform(df["City"])
df["Card_encoded"] = le_card.fit_transform(df["Card Type"])
df["Gender_encoded"] = le_gender.fit_transform(df["Gender"])
df["Exp_encoded"] = le_exp.fit_transform(df["Exp Type"])

X_exp = df[["City_encoded", "Card_encoded", "Gender_encoded", "Amount"]]
y_exp = df["Exp_encoded"]

X_train_exp, X_test_exp, y_train_exp, y_test_exp = train_test_split(X_exp, y_exp, test_size=0.2, random_state=42)

model_exp = RandomForestClassifier(n_estimators=100, random_state=42)
model_exp.fit(X_train_exp, y_train_exp)

# Save model & encoders
with open("rf_model.pkl", "wb") as f:
    pickle.dump(model_exp, f)

with open("encoders.pkl", "wb") as f:
    pickle.dump({
        "city": le_city,
        "card": le_card,
        "gender": le_gender,
        "exp": le_exp
    }, f)

print("✅ Expense type model saved.")

# =========================
# Model 2: Card Tier Upgrade Predictor
# =========================

# Feature engineering for user-level stats
df_grouped = df.groupby(["Card Type", "Gender", "City"]).agg({
    "Amount": "mean",
    "Exp Type": lambda x: (x == "Travel").sum() + (x == "Bills").sum()
}).rename(columns={"Amount": "Avg_Amount", "Exp Type": "HighEnd_Freq"})

df_grouped.reset_index(inplace=True)

# Create binary label: recommend upgrade if Avg_Amount > 2500 and HighEnd_Freq ≥ 3
df_grouped["Upgrade_Label"] = (
    (df_grouped["Avg_Amount"] > 2500) & (df_grouped["HighEnd_Freq"] >= 3)
).astype(int)

# Encode features
le_upgrade_card = LabelEncoder()
le_upgrade_gender = LabelEncoder()
le_upgrade_city = LabelEncoder()

df_grouped["Card_Enc"] = le_upgrade_card.fit_transform(df_grouped["Card Type"])
df_grouped["Gender_Enc"] = le_upgrade_gender.fit_transform(df_grouped["Gender"])
df_grouped["City_Enc"] = le_upgrade_city.fit_transform(df_grouped["City"])

X_upgrade = df_grouped[["Card_Enc", "Gender_Enc", "City_Enc", "Avg_Amount", "HighEnd_Freq"]]
y_upgrade = df_grouped["Upgrade_Label"]

X_train_upg, X_test_upg, y_train_upg, y_test_upg = train_test_split(X_upgrade, y_upgrade, test_size=0.2, random_state=42)

model_upgrade = RandomForestClassifier()
model_upgrade.fit(X_train_upg, y_train_upg)

with open("upgrade_model.pkl", "wb") as f:
    pickle.dump(model_upgrade, f)

with open("upgrade_encoders.pkl", "wb") as f:
    pickle.dump({
        "card": le_upgrade_card,
        "gender": le_upgrade_gender,
        "city": le_upgrade_city
    }, f)

print("✅ Upgrade recommendation model saved.")
